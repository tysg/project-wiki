class TNode
{
public:

};