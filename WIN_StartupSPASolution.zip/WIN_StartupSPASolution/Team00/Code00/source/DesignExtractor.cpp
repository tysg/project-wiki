#include<stdio.h>
#include <iostream>
#include <string>
#include <vector>

using namespace std;


#include "PKB.h"

int DesignExtractor () {
	return 0;
}
