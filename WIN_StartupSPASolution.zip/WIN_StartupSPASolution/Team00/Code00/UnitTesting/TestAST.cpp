#include "stdafx.h"
#include "CppUnitTest.h"
#include "TNode.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTesting
{		
	TEST_CLASS(TestAST)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			TNode T;
			// TODO: Your test code here
		}

	};
}